from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
from .models import Customer, Lead
from employees.models import Employee
import json


@csrf_exempt
@require_http_methods(["GET"])
def health_check(request):
    """Health check endpoint for integration testing"""
    return JsonResponse({
        'status': 'ok',
        'service': 'FagiCRM',
        'version': '1.0.0',
        'timestamp': timezone.now().isoformat()
    })


@csrf_exempt
@require_http_methods(["GET"])
def customers_api(request):
    """API endpoint to get customers for asset manager integration"""
    # Simple API key authentication (in production, use proper authentication)
    api_key = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not api_key:
        return JsonResponse({'error': 'API key required'}, status=401)
    
    try:
        customers = Customer.objects.all().select_related('assigned_employee__user')
        
        # Search functionality
        search = request.GET.get('search')
        if search:
            customers = customers.filter(
                Q(first_name__icontains=search) |
                Q(last_name__icontains=search) |
                Q(company_name__icontains=search) |
                Q(email__icontains=search)
            )
        
        # Filter by status
        status_filter = request.GET.get('status')
        if status_filter:
            customers = customers.filter(status=status_filter)
        
        # Pagination
        page_size = int(request.GET.get('page_size', 50))
        page = int(request.GET.get('page', 1))
        
        paginator = Paginator(customers, page_size)
        page_obj = paginator.get_page(page)
        
        # Serialize customer data
        customers_data = []
        for customer in page_obj:
            customer_data = {
                'id': customer.id,
                'first_name': customer.first_name,
                'last_name': customer.last_name,
                'company_name': customer.company_name,
                'email': customer.email,
                'phone': customer.phone,
                'address_line1': customer.address_line1,
                'address_line2': customer.address_line2,
                'city': customer.city,
                'state': customer.state,
                'postal_code': customer.postal_code,
                'country': customer.country,
                'status': customer.status,
                'customer_type': customer.customer_type,
                'created_at': customer.created_at.isoformat(),
                'updated_at': customer.updated_at.isoformat(),
                'assigned_employee': None
            }
            
            # Include assigned employee data
            if customer.assigned_employee:
                customer_data['assigned_employee'] = {
                    'id': customer.assigned_employee.id,
                    'employee_id': customer.assigned_employee.employee_id,
                    'user': {
                        'id': customer.assigned_employee.user.id,
                        'username': customer.assigned_employee.user.username,
                        'first_name': customer.assigned_employee.user.first_name,
                        'last_name': customer.assigned_employee.user.last_name,
                        'email': customer.assigned_employee.user.email,
                    },
                    'position': customer.assigned_employee.position,
                    'department': customer.assigned_employee.department.name if customer.assigned_employee.department else None,
                }
            
            customers_data.append(customer_data)
        
        return JsonResponse({
            'results': customers_data,
            'count': paginator.count,
            'num_pages': paginator.num_pages,
            'current_page': page_obj.number,
            'has_next': page_obj.has_next(),
            'has_previous': page_obj.has_previous(),
        })
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def employees_api(request):
    """API endpoint to get employees for asset manager integration"""
    # Simple API key authentication
    api_key = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not api_key:
        return JsonResponse({'error': 'API key required'}, status=401)
    
    try:
        employees = Employee.objects.filter(employment_status='active').select_related('user', 'department')
        
        # Serialize employee data
        employees_data = []
        for employee in employees:
            employee_data = {
                'id': employee.id,
                'employee_id': employee.employee_id,
                'user': {
                    'id': employee.user.id,
                    'username': employee.user.username,
                    'first_name': employee.user.first_name,
                    'last_name': employee.user.last_name,
                    'email': employee.user.email,
                },
                'phone': employee.phone,
                'position': employee.position,
                'employment_status': employee.employment_status,
                'employment_type': employee.employment_type,
                'hire_date': employee.hire_date.isoformat(),
                'department': {
                    'id': employee.department.id,
                    'name': employee.department.name,
                    'description': employee.department.description,
                } if employee.department else None,
                'manager': {
                    'id': employee.manager.id,
                    'employee_id': employee.manager.employee_id,
                    'name': employee.manager.full_name,
                } if employee.manager else None,
            }
            employees_data.append(employee_data)
        
        return JsonResponse({
            'results': employees_data,
            'count': len(employees_data)
        })
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
@require_http_methods(["POST"])
def asset_assignments_api(request):
    """API endpoint to receive asset assignment data from asset manager"""
    # Simple API key authentication
    api_key = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not api_key:
        return JsonResponse({'error': 'API key required'}, status=401)
    
    try:
        data = json.loads(request.body)
        
        # Validate required fields
        required_fields = ['customer_id', 'asset_tag', 'asset_name']
        for field in required_fields:
            if field not in data:
                return JsonResponse({'error': f'Missing required field: {field}'}, status=400)
        
        # Find the customer
        try:
            customer = Customer.objects.get(id=data['customer_id'])
        except Customer.DoesNotExist:
            return JsonResponse({'error': 'Customer not found'}, status=404)
        
        # For now, we'll just log the assignment data
        # In a full implementation, you might want to store this in a separate model
        # or add notes to the customer record
        
        # Add a note to the customer about the asset assignment
        from .models import CustomerNote
        from django.contrib.auth.models import User
        
        # Try to find a system user for the note
        system_user = User.objects.filter(is_staff=True).first()
        if not system_user:
            system_user = User.objects.first()
        
        note_content = f"Asset Assignment: {data['asset_tag']} - {data['asset_name']}\n"
        note_content += f"Assignment Type: {data.get('assignment_type', 'Unknown')}\n"
        note_content += f"Assigned Date: {data.get('assigned_date', 'Unknown')}\n"
        
        if data.get('contract_number'):
            note_content += f"Contract: {data['contract_number']}\n"
        
        if data.get('monthly_fee'):
            note_content += f"Monthly Fee: ${data['monthly_fee']}\n"
        
        if data.get('total_value'):
            note_content += f"Total Value: ${data['total_value']}\n"
        
        if data.get('notes'):
            note_content += f"Notes: {data['notes']}\n"
        
        CustomerNote.objects.create(
            customer=customer,
            note=note_content,
            created_by=system_user,
            is_important=True
        )
        
        return JsonResponse({
            'status': 'success',
            'message': 'Asset assignment recorded',
            'customer_id': customer.id,
            'asset_tag': data['asset_tag']
        })
        
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
@require_http_methods(["GET"])
def customer_detail_api(request, customer_id):
    """API endpoint to get detailed customer information"""
    # Simple API key authentication
    api_key = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not api_key:
        return JsonResponse({'error': 'API key required'}, status=401)
    
    try:
        customer = Customer.objects.select_related('assigned_employee__user').get(id=customer_id)
        
        customer_data = {
            'id': customer.id,
            'first_name': customer.first_name,
            'last_name': customer.last_name,
            'company_name': customer.company_name,
            'email': customer.email,
            'phone': customer.phone,
            'alternate_phone': customer.alternate_phone,
            'address_line1': customer.address_line1,
            'address_line2': customer.address_line2,
            'city': customer.city,
            'state': customer.state,
            'postal_code': customer.postal_code,
            'country': customer.country,
            'status': customer.status,
            'customer_type': customer.customer_type,
            'preferred_contact_method': customer.preferred_contact_method,
            'total_spent': float(customer.total_spent),
            'lifetime_value': float(customer.lifetime_value),
            'created_at': customer.created_at.isoformat(),
            'updated_at': customer.updated_at.isoformat(),
            'assigned_employee': None
        }
        
        # Include assigned employee data
        if customer.assigned_employee:
            customer_data['assigned_employee'] = {
                'id': customer.assigned_employee.id,
                'employee_id': customer.assigned_employee.employee_id,
                'user': {
                    'id': customer.assigned_employee.user.id,
                    'username': customer.assigned_employee.user.username,
                    'first_name': customer.assigned_employee.user.first_name,
                    'last_name': customer.assigned_employee.user.last_name,
                    'email': customer.assigned_employee.user.email,
                },
                'position': customer.assigned_employee.position,
                'department': customer.assigned_employee.department.name if customer.assigned_employee.department else None,
            }
        
        # Include recent notes
        recent_notes = customer.notes.all()[:5]
        customer_data['recent_notes'] = []
        for note in recent_notes:
            customer_data['recent_notes'].append({
                'id': note.id,
                'note': note.note,
                'is_important': note.is_important,
                'created_at': note.created_at.isoformat(),
                'created_by': note.created_by.get_full_name() if note.created_by else 'System'
            })
        
        return JsonResponse(customer_data)
        
    except Customer.DoesNotExist:
        return JsonResponse({'error': 'Customer not found'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)